
from src.pipeline import main

if __name__ == "__main__":
    main()
